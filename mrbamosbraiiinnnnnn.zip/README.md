# Interaction Design Project

Kitty the little bamboo

# Dependencies

* Arduino IDE >= 1.5
* bash or zsh
* git         (optional)
